import SwiftUI

// =============================================================================
// HeroSectionView.swift — Top Banner
// =============================================================================
// The first thing students see at the top of the screen.
// Shows the app icon and title.
//
// IDEAS TO CUSTOMISE:
//   • Swap the SF Symbol — try "sun.max.fill", "tv.fill", or "bolt.house.fill"
//     Browse all icons free in the SF Symbols app (developer.apple.com/sf-symbols)
//   • Change the title and subtitle text to match your theme
//   • Add a colourful background or gradient behind the icon
//   • Wrap the icon in a coloured circle for a badge look
//   • Add a subtle animation on appear (e.g. the icon scales up)
//
// EXAMPLE — coloured icon badge:
//   ZStack {
//       Circle()
//           .fill(Color.yellow)
//           .frame(width: 90, height: 90)
//       Image(systemName: "house.fill")
//           .font(.system(size: 40))
//           .foregroundStyle(.white)
//   }
// =============================================================================

struct HeroSectionView: View {
    var body: some View {
        VStack(spacing: 16) {

            // ── App icon ──────────────────────────────────────────────────
            // CUSTOMIZE: Replace "house.fill" with any SF Symbol name.
            // CUSTOMIZE: Change .foregroundStyle to your chosen icon colour.
            Image(systemName: "house.fill")
                .font(.system(size: 56))
                .foregroundStyle(.primary)

            // ── Title and subtitle ────────────────────────────────────────
            VStack(spacing: 6) {
                // CUSTOMIZE: Change the app title
                Text("Simpson's House")
                    .font(.largeTitle)
                    .fontWeight(.bold)

                // CUSTOMIZE: Change the subtitle
                Text("Smart Home Control")
                    .font(.title3)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 20)
        .frame(maxWidth: .infinity)
        // CUSTOMIZE: Add a background and rounded corners to make this a card.
        // Examples:
        //   .background(Color.yellow)
        //   .background(LinearGradient(colors: [.yellow, .orange], startPoint: .top, endPoint: .bottom))
        //   .background(.ultraThinMaterial)
        // Then round the corners:
        //   .clipShape(RoundedRectangle(cornerRadius: 20))
        // And optionally add a border:
        //   .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.orange, lineWidth: 2))
    }
}

#Preview {
    HeroSectionView()
        .padding()
}
