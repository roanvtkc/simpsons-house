import SwiftUI

// =============================================================================
// DebugConnectionView.swift — Developer Debug Panel
// =============================================================================
// ⚠️  FOR TEACHERS / DEVELOPERS ONLY — NOT SHOWN TO STUDENTS  ⚠️
//
// This view is intentionally NOT referenced anywhere in ContentView.swift,
// so students never see it. It was built during development to diagnose
// a tricky issue where the MQTT CONNACK packet was received correctly but
// the isConnected flag wasn't updating the UI — the "Force Fix" button
// manually overrides that state so testing can continue.
//
// ── HOW TO RE-ENABLE FOR DEBUGGING ────────────────────────────────────────
// Open ContentView.swift and add this view inside the ScrollView's VStack,
// just below the ConnectionStatusCard:
//
//     DebugConnectionView(mqttClient: mqttClient)
//
// Remove it again before distributing to students.
//
// ── WHAT THE "FORCE FIX" BUTTON DOES ──────────────────────────────────────
// Calls mqttClient.forceConnectionFix(), which manually sets isConnected = true
// without going through the MQTT handshake. Useful when:
//   • The WebSocket connects and CONNACK is received (visible in Logs)
//   • But the device controls section still isn't appearing
// This lets you verify the UI logic works independently of the network state.
// =============================================================================

struct DebugConnectionView: View {
    let mqttClient: SimpsonsHouseMQTTClient

    var body: some View {
        VStack(spacing: 12) {
            Text("🐛 Debug Info")
                .font(.headline)
                .fontWeight(.bold)

            VStack(alignment: .leading, spacing: 8) {
                Text("Client ID: \(mqttClient.debugClientId.prefix(8))...")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Text("Connection State: \(mqttClient.isConnected ? "✅ CONNECTED" : "❌ DISCONNECTED")")
                    .font(.caption)
                    .foregroundStyle(mqttClient.isConnected ? .green : .red)

                Text("Status: \(mqttClient.connectionStatus)")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                if mqttClient.receivedMessages.contains(where: { $0.contains("CONNACK return code: 0") }) {
                    Text("🎯 MQTT SUCCESS DETECTED IN LOGS!")
                        .font(.caption)
                        .fontWeight(.bold)
                        .foregroundStyle(.orange)
                }

                Text("Device Controls Should Show: \(mqttClient.isConnected ? "YES" : "NO")")
                    .font(.caption)
                    .fontWeight(.bold)
                    .foregroundStyle(mqttClient.isConnected ? .green : .red)

                Text("Last Update: \(Date().formatted(.dateTime.hour().minute().second()))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Button("🔧 FORCE FIX CONNECTION") {
                mqttClient.forceConnectionFix()
            }
            .font(.headline)
            .fontWeight(.bold)
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 44)
            .background(.orange.gradient, in: RoundedRectangle(cornerRadius: 12))
        }
        .padding(16)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .strokeBorder(.orange.opacity(0.5), lineWidth: 2)
        )
    }
}
