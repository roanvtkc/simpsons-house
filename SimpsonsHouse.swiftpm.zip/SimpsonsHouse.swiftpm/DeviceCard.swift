import SwiftUI

// =============================================================================
// DeviceCard.swift — Reusable Device Tile
// =============================================================================
// Used for the Living Room Light and Front Door.
// Tapping the card calls the action closure, which toggles the device.
//
// Parameters (set by DeviceControlsSection — don't change these):
//   icon        — SF Symbol name for the device icon
//   title       — Main label  (e.g. "Living Room")
//   subtitle    — Secondary label  (e.g. "Light")
//   isOn        — Whether the device is currently active
//   accentColor — The highlight colour used when the device is ON
//   action      — The toggle function to call (do not change!)
//
// IDEAS TO CUSTOMISE:
//   • Add a coloured background that changes when isOn is true
//   • Show a different icon for ON vs OFF states
//   • Add a glowing shadow when the device is active
//   • Make the whole card appear "lit up" when turned on
//   • Style the ON/OFF badge pill with a colour
//
// EXAMPLE — active glow effect:
//   .background(isOn ? accentColor.opacity(0.12) : Color(.secondarySystemBackground))
//   .clipShape(RoundedRectangle(cornerRadius: 16))
//   .shadow(color: isOn ? accentColor.opacity(0.4) : .clear, radius: 8)
// =============================================================================

struct DeviceCard: View {
    let icon: String
    let title: String
    let subtitle: String
    let isOn: Bool
    let accentColor: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 12) {

                // ── Icon row ──────────────────────────────────────────────
                HStack {
                    // CUSTOMIZE: Wrap the icon in a coloured circle background.
                    // Example:
                    //   ZStack {
                    //       Circle()
                    //           .fill(isOn ? accentColor.opacity(0.2) : Color(.systemGray6))
                    //           .frame(width: 48, height: 48)
                    //       Image(systemName: icon)
                    //           .font(.title2)
                    //           .foregroundStyle(isOn ? accentColor : .secondary)
                    //   }
                    Image(systemName: icon)
                        .font(.title2)
                        .foregroundStyle(isOn ? accentColor : .secondary)

                    Spacer()

                    // On/Off indicator
                    // CUSTOMIZE: Replace with a Toggle, a custom shape, or a badge
                    Circle()
                        .fill(isOn ? accentColor : Color(.systemGray4))
                        .frame(width: 14, height: 14)
                }

                // ── Text labels ───────────────────────────────────────────
                VStack(alignment: .leading, spacing: 4) {
                    // CUSTOMIZE: Change font size, weight, or colour
                    Text(title)
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundStyle(.primary)

                    Text(subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    // ON / OFF state badge
                    // CUSTOMIZE: Style with a coloured pill background.
                    // Example:
                    //   Text(isOn ? "ON" : "OFF")
                    //       .font(.caption2).fontWeight(.bold)
                    //       .foregroundStyle(isOn ? accentColor : .secondary)
                    //       .padding(.horizontal, 8).padding(.vertical, 2)
                    //       .background(isOn ? accentColor.opacity(0.15) : Color(.systemGray6))
                    //       .clipShape(Capsule())
                    Text(isOn ? "ON" : "OFF")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundStyle(isOn ? accentColor : .secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(16)
            .frame(maxWidth: .infinity)
            .frame(height: 120)
            // CUSTOMIZE: Add a background and border to the card.
            // The border/shadow could change based on isOn for an "active" effect.
            .background(Color(.secondarySystemBackground))
            .clipShape(RoundedRectangle(cornerRadius: 16))
        }
        .buttonStyle(PlainButtonStyle())
    }
}

#Preview {
    HStack {
        DeviceCard(icon: "lightbulb.fill", title: "Living Room", subtitle: "Light",
                   isOn: true, accentColor: .yellow, action: {})
        DeviceCard(icon: "door.right.hand.open", title: "Front Door", subtitle: "Security",
                   isOn: false, accentColor: .brown, action: {})
    }
    .padding()
}
