import SwiftUI

// =============================================================================
// DeviceControlsSection.swift — Device Grid (shown when connected)
// =============================================================================
// Lays out all device cards in a 2-column grid.
// The Garage Door card spans both columns because it has two buttons.
//
// Card layout:
//   [ Light Card ]  [ Garage Door Card (spans 2 cols) ]
//   [       Front Door Card (spans 2 cols)            ]
//
// IDEAS TO CUSTOMISE:
//   • Change the "House is Online!" heading or add an icon/emoji
//   • Style the "X/3 Active" badge with a coloured background
//   • Adjust the grid spacing between cards
//   • Add a coloured card background to the whole section
//   • Add a divider or section title above the grid
// =============================================================================

struct DeviceControlsSection: View {
    @ObservedObject var mqttClient: SimpsonsHouseMQTTClient

    var body: some View {
        VStack(spacing: 20) {

            // ── Section header ────────────────────────────────────────────
            HStack {
                // CUSTOMIZE: Change the heading text or add an emoji
                Text("House is Online!")
                    .font(.title2)
                    .fontWeight(.bold)

                Spacer()

                // Active devices count badge
                // CUSTOMIZE: Style with a bold colour background and rounded shape.
                // Example:
                //   .foregroundStyle(.white)
                //   .background(Color.green)
                //   .clipShape(Capsule())
                Text("\(activeDevicesCount)/3 Active")
                    .font(.caption)
                    .fontWeight(.medium)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
            }

            // ── 2-column device card grid ─────────────────────────────────
            LazyVGrid(columns: [
                GridItem(.flexible(), spacing: 16),
                GridItem(.flexible(), spacing: 16)
            ], spacing: 16) {

                // Living Room Light — tapping toggles the LED on GPIO 17
                DeviceCard(
                    icon: "lightbulb.fill",
                    title: "Living Room",
                    subtitle: "Light",
                    isOn: mqttClient.deviceStates.lightOn,
                    accentColor: .yellow,
                    action: { mqttClient.toggleLight() }
                )

                // Garage Door — has separate OPEN and CLOSE buttons
                // See GarageDoorCard.swift to customise this card
                GarageDoorCard(mqttClient: mqttClient)

                // Front Door Servo — tapping toggles the servo on GPIO 23
                DeviceCard(
                    icon: "door.right.hand.open",
                    title: "Front Door",
                    subtitle: "Security",
                    isOn: mqttClient.deviceStates.doorOpen,
                    accentColor: .brown,
                    action: { mqttClient.toggleDoor() }
                )
                .gridCellColumns(2)
            }
        }
        .padding(24)
        // CUSTOMIZE: Add a section card background here.
        // Example:
        //   .background(Color(.secondarySystemBackground))
        //   .clipShape(RoundedRectangle(cornerRadius: 20))
        //   .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.green.opacity(0.3), lineWidth: 2))
    }

    // Counts how many devices are currently active (used by the badge)
    private var activeDevicesCount: Int {
        var count = 0
        if mqttClient.deviceStates.lightOn    { count += 1 }
        if mqttClient.deviceStates.garageOpen { count += 1 }
        if mqttClient.deviceStates.doorOpen   { count += 1 }
        return count
    }
}
