import SwiftUI

// =============================================================================
// LogsView.swift — Activity Logs Sheet
// =============================================================================
// Shows a live feed of MQTT messages and connection events.
// Opens when the user taps the logs (≡) button in the connection card.
//
// This is a useful debugging tool — students can see exactly what
// commands are being sent when they press buttons in the app.
// The most recent 100 messages are shown, newest first.
// =============================================================================

struct LogsView: View {
    let messages: [String]
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Group {
                if messages.isEmpty {
                    ContentUnavailableView(
                        "No Activity Yet",
                        systemImage: "list.bullet.clipboard",
                        description: Text("Connect to Simpson's House to see activity logs")
                    )
                } else {
                    List {
                        Section("Recent Activity") {
                            ForEach(Array(messages.suffix(100).reversed().enumerated()), id: \.offset) { _, message in
                                HStack(spacing: 12) {
                                    Text(icon(for: message))
                                        .font(.caption)

                                    Text(message)
                                        .font(.system(.footnote, design: .monospaced))
                                        .foregroundStyle(.primary)
                                }
                                .padding(.vertical, 4)
                            }
                        }
                    }
                }
            }
            .navigationTitle("Activity Logs")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
    }

    private func icon(for message: String) -> String {
        if message.contains("Connected")                      { return "✅" }
        if message.contains("failed") || message.contains("Error") { return "❌" }
        if message.contains("Keep-alive")                     { return "🏓" }
        if message.contains("DEBUG")                          { return "🐛" }
        if message.contains("FORCING")                        { return "🚨" }
        if message.contains("OPEN") || message.contains("CLOSE") { return "🏠" }
        if message.contains("ON")   || message.contains("OFF")   { return "🏠" }
        return "📨"
    }
}
