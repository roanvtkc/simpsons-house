import SwiftUI

// =============================================================================
// GarageDoorCard.swift — Garage Door Control Card
// =============================================================================
// Unlike the other device cards which are simple tap-to-toggle, the
// Garage Door has two explicit buttons — CLOSE and OPEN — because
// the servo needs to know the intended direction.
//
// The card spans both columns in the device grid (set via .gridCellColumns(2)).
//
// IDEAS TO CUSTOMISE:
//   • Give the OPEN button a green background and CLOSE button a red one
//   • Add a large state icon (e.g. "garage.open" / "garage.closed") in the header
//   • Show a warning colour/message when the door has been open a long time
//   • Style the card background to match the rest of your theme
//   • Add an animation when the state changes
//
// EXAMPLE — coloured action buttons:
//   // CLOSE button background:
//   .background(!mqttClient.deviceStates.garageOpen ? Color.blue : Color.blue.opacity(0.1))
//   // OPEN button background:
//   .background(mqttClient.deviceStates.garageOpen ? Color.orange : Color.orange.opacity(0.1))
// =============================================================================

struct GarageDoorCard: View {
    @ObservedObject var mqttClient: SimpsonsHouseMQTTClient

    var body: some View {
        VStack(spacing: 16) {

            // ── Header row ────────────────────────────────────────────────
            HStack {
                // Garage icon
                // CUSTOMIZE: Wrap in a coloured circle, or switch the icon
                // between "garage" (closed) and "garage.open" (open)
                Image(systemName: mqttClient.deviceStates.garageOpen ? "garage.open" : "garage")
                    .font(.title2)
                    .foregroundStyle(mqttClient.deviceStates.garageOpen ? .orange : .secondary)

                // Labels
                VStack(alignment: .leading, spacing: 4) {
                    Text("Garage Door")
                        .font(.headline)
                        .fontWeight(.semibold)

                    // CUSTOMIZE: Update this subtitle
                    Text("Servo Motor")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                // Current state label
                // CUSTOMIZE: Style as a coloured badge pill.
                // Example:
                //   Text(mqttClient.deviceStates.garageOpen ? "OPEN" : "CLOSED")
                //       .font(.caption).fontWeight(.bold).foregroundStyle(.white)
                //       .padding(.horizontal, 8).padding(.vertical, 4)
                //       .background(mqttClient.deviceStates.garageOpen ? Color.orange : Color.gray)
                //       .clipShape(Capsule())
                Text(mqttClient.deviceStates.garageOpen ? "OPEN" : "CLOSED")
                    .font(.headline)
                    .fontWeight(.bold)
                    .foregroundStyle(mqttClient.deviceStates.garageOpen ? .orange : .secondary)
            }

            // ── CLOSE and OPEN buttons ────────────────────────────────────
            // DO NOT change the actions — they call toggleGarageDoor()
            HStack(spacing: 12) {

                // CLOSE button
                // This button is "active" (highlighted) when the door is CLOSED
                Button(action: {
                    if mqttClient.deviceStates.garageOpen {
                        mqttClient.toggleGarageDoor()
                    }
                }) {
                    VStack(spacing: 6) {
                        Image(systemName: "garage.closed")
                            .font(.title3)
                        Text("CLOSE")
                            .font(.caption)
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    // CUSTOMIZE: Style these states — the "active" state should
                    // look more prominent than the "inactive" state.
                    // When door is CLOSED: this button is in its active/selected state.
                    .foregroundStyle(!mqttClient.deviceStates.garageOpen ? .white : .blue)
                    .background(!mqttClient.deviceStates.garageOpen ? Color.blue : Color.blue.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                }
                .buttonStyle(PlainButtonStyle())

                // OPEN button
                // This button is "active" (highlighted) when the door is OPEN
                Button(action: {
                    if !mqttClient.deviceStates.garageOpen {
                        mqttClient.toggleGarageDoor()
                    }
                }) {
                    VStack(spacing: 6) {
                        Image(systemName: "garage.open")
                            .font(.title3)
                        Text("OPEN")
                            .font(.caption)
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    // CUSTOMIZE: Style these states.
                    // When door is OPEN: this button is in its active/selected state.
                    .foregroundStyle(mqttClient.deviceStates.garageOpen ? .white : .orange)
                    .background(mqttClient.deviceStates.garageOpen ? Color.orange : Color.orange.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                }
                .buttonStyle(PlainButtonStyle())
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity)
        // CUSTOMIZE: Add a card background. Try a subtle orange tint when the door is open:
        //   .background(mqttClient.deviceStates.garageOpen ? Color.orange.opacity(0.05) : Color(.secondarySystemBackground))
        //   .clipShape(RoundedRectangle(cornerRadius: 16))
        //   .overlay(RoundedRectangle(cornerRadius: 16).stroke(mqttClient.deviceStates.garageOpen ? Color.orange : .clear, lineWidth: 2))
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .gridCellColumns(2)
    }
}
