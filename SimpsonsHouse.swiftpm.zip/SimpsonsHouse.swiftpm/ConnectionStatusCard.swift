import SwiftUI

// =============================================================================
// ConnectionStatusCard.swift — Connect / Disconnect Panel
// =============================================================================
// Shows the current connection status and the main Connect button.
// Also has small icon buttons to open the Info and Logs sheets.
//
// IDEAS TO CUSTOMISE:
//   • Give the Connect button a bold colour, e.g. .background(Color.blue)
//   • Make the Disconnect button a different colour (e.g. red)
//   • Style the status pill (the green/red dot and label)
//   • Add a pulsing animation to the dot when connected
//   • Wrap everything in a rounded card with a shadow
//
// EXAMPLE — styled Connect button:
//   .foregroundStyle(.white)
//   .background(mqttClient.isConnected ? Color.red : Color.blue)
//   .clipShape(RoundedRectangle(cornerRadius: 16))
// =============================================================================

struct ConnectionStatusCard: View {
    @ObservedObject var mqttClient: SimpsonsHouseMQTTClient
    @Binding var showingInfo: Bool
    @Binding var showingLogs: Bool

    var body: some View {
        VStack(spacing: 18) {

            // ── Top row: status pill + info/logs buttons ──────────────────
            HStack {

                // Status pill — shows "Connected" (green) or "Disconnected" (red)
                HStack(spacing: 8) {
                    // CUSTOMIZE: Change the dot size or add an animation when connected.
                    // Example pulse animation:
                    //   Circle()
                    //       .fill(mqttClient.isConnected ? Color.green : Color.red)
                    //       .frame(width: 10, height: 10)
                    //       .scaleEffect(mqttClient.isConnected ? 1.2 : 1.0)
                    //       .animation(.easeInOut(duration: 0.8).repeatForever(), value: mqttClient.isConnected)
                    Circle()
                        .fill(mqttClient.isConnected ? Color.green : Color.red)
                        .frame(width: 10, height: 10)

                    // CUSTOMIZE: Change the font weight, size, or colour
                    Text(mqttClient.isConnected ? "Connected" : "Disconnected")
                        .font(.caption)
                        .fontWeight(.semibold)
                        .foregroundStyle(mqttClient.isConnected ? .green : .red)
                }
                // CUSTOMIZE: Style the pill with a background capsule.
                // Example:
                //   .padding(.horizontal, 12)
                //   .padding(.vertical, 6)
                //   .background(mqttClient.isConnected ? Color.green.opacity(0.1) : Color.red.opacity(0.1))
                //   .clipShape(Capsule())
                .padding(.horizontal, 12)
                .padding(.vertical, 6)

                Spacer()

                // Info and Logs icon buttons
                HStack(spacing: 16) {
                    Button {
                        showingInfo = true
                    } label: {
                        // CUSTOMIZE: Change the icon or add a text label
                        Image(systemName: "info.circle.fill")
                            .font(.title3)
                            .foregroundStyle(.blue)
                    }

                    Button {
                        showingLogs = true
                    } label: {
                        // CUSTOMIZE: Change the icon or add a text label
                        Image(systemName: "list.bullet.circle.fill")
                            .font(.title3)
                            .foregroundStyle(.purple)
                    }
                }
            }

            // ── Status message ────────────────────────────────────────────
            // Shows what the client is doing (e.g. "Connecting...", "Connected!")
            // CUSTOMIZE: Add a background box around this text, change the font
            Text(mqttClient.connectionStatus)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 16)
                .padding(.vertical, 8)

            // ── Connect / Disconnect button ───────────────────────────────
            // DO NOT change the action — it calls connect() or disconnect()
            Button {
                if mqttClient.isConnected {
                    mqttClient.disconnect()
                } else {
                    mqttClient.connect()
                }
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: mqttClient.isConnected ? "house.slash.fill" : "house.fill")
                        .font(.title3)

                    Text(mqttClient.isConnected ? "Disconnect" : "Connect")
                        .font(.headline)
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
                .frame(height: 54)
                // CUSTOMIZE: Style the button background and text colour.
                // Tip: use different colours for Connect vs Disconnect states.
                // Example:
                //   .foregroundStyle(.white)
                //   .background(mqttClient.isConnected ? Color.red : Color.blue)
                //   .clipShape(RoundedRectangle(cornerRadius: 16))
                .foregroundStyle(.white)
                .background(mqttClient.isConnected ? Color.red : Color.blue)
                .clipShape(RoundedRectangle(cornerRadius: 16))
            }
        }
        .padding(24)
        // CUSTOMIZE: Wrap in a card background.
        // Example:
        //   .background(Color(.secondarySystemBackground))
        //   .clipShape(RoundedRectangle(cornerRadius: 20))
        //   .shadow(color: .black.opacity(0.08), radius: 8, y: 4)
    }
}
