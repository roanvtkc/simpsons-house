import SwiftUI

// =============================================================================
// ConnectionPromptView.swift — Offline Placeholder
// =============================================================================
// Shown in place of the device cards when the app is not connected.
// Encourages the user to tap the Connect button above.
//
// IDEAS TO CUSTOMISE:
//   • Change the icon — try "house.slash.fill" or "wifi.exclamationmark"
//   • Update the heading and description text for your project's theme
//   • Add a subtle background card with rounded corners
//   • Add a fade-in animation when this view appears
//   • Add a tip or instruction about how to connect
// =============================================================================

struct ConnectionPromptView: View {
    var body: some View {
        VStack(spacing: 20) {

            // CUSTOMIZE: Change the icon to match your theme
            Image(systemName: "wifi.slash")
                .font(.system(size: 56))
                .foregroundStyle(.secondary)

            VStack(spacing: 12) {
                // CUSTOMIZE: Change the heading
                Text("Connect to Get Started")
                    .font(.title3)
                    .fontWeight(.semibold)

                // CUSTOMIZE: Update the description text
                Text("Connect to Simpson's House to control your smart home devices")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
        .padding(32)
        .frame(maxWidth: .infinity)
        // CUSTOMIZE: Add a card background here.
        // Example:
        //   .background(Color(.secondarySystemBackground))
        //   .clipShape(RoundedRectangle(cornerRadius: 20))
    }
}

#Preview {
    ConnectionPromptView()
        .padding()
}
