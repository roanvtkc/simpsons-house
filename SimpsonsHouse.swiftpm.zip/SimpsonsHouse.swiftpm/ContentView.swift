import SwiftUI

// =============================================================================
// ContentView.swift — Main Layout
// =============================================================================
// This is the root view of the app. It arranges all the major sections
// in a vertical scroll view and wires them up to the MQTT client.
//
// You generally don't need to change the structure here, but you can:
//   • Adjust the spacing between sections (.padding, VStack spacing)
//   • Change the overall screen background colour
//   • Reorder the sections if you want a different layout
// =============================================================================

struct ContentView: View {
    @StateObject private var mqttClient = SimpsonsHouseMQTTClient()
    @State private var showingLogs = false
    @State private var showingInfo = false
    @State private var forceRefresh = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {

                    // ── Hero banner ───────────────────────────────────────
                    // See HeroSectionView.swift to customise this
                    HeroSectionView()
                        .padding(.top, 8)

                    // ── Connection card ───────────────────────────────────
                    // See ConnectionStatusCard.swift to customise this
                    ConnectionStatusCard(
                        mqttClient: mqttClient,
                        showingInfo: $showingInfo,
                        showingLogs: $showingLogs
                    )
                    .id("connection-\(mqttClient.isConnected)-\(forceRefresh)")

                    // ── Device controls / offline prompt ──────────────────
                    // DeviceControlsSection is shown when connected.
                    // ConnectionPromptView is shown when offline.
                    if mqttClient.isConnected {
                        DeviceControlsSection(mqttClient: mqttClient)
                            .id("controls-\(mqttClient.isConnected)-\(forceRefresh)")
                    } else {
                        ConnectionPromptView()
                            .id("prompt-\(mqttClient.isConnected)-\(forceRefresh)")
                    }

                    Spacer(minLength: 100)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 40)
            }
            // CUSTOMIZE: Change the background colour of the whole screen.
            // Examples:
            //   .background(Color.yellow.opacity(0.05))          // subtle tint
            //   .background(Color("MyBackgroundColor"))           // named asset
            //   .background(LinearGradient(colors: [.blue.opacity(0.1), .purple.opacity(0.05)],
            //                              startPoint: .top, endPoint: .bottom))
            .background(Color(.systemBackground))
            .ignoresSafeArea(edges: .bottom)
            .navigationBarHidden(true)
            .onAppear {
                print("🏠 CONSOLE: ContentView appeared with client ID: \(mqttClient.debugClientId)")
            }
            .onReceive(mqttClient.objectWillChange) { _ in
                print("🔄 CONSOLE: MQTT Client changed - forcing UI refresh")
                forceRefresh.toggle()
            }
        }
        .sheet(isPresented: $showingLogs) {
            LogsView(messages: mqttClient.receivedMessages)
        }
        .sheet(isPresented: $showingInfo) {
            InfoView()
        }
    }
}

#Preview {
    ContentView()
}
