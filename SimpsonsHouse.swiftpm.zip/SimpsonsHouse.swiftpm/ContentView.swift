import SwiftUI
import Network
import Foundation

// MARK: - MQTT WebSocket Client for Simpson's House
class SimpsonsHouseMQTTClient: NSObject, ObservableObject {
    @Published var isConnected = false {
        didSet {
            print("🚨 CONSOLE: isConnected changed from \(oldValue) to \(isConnected)")
            print("🚨 CONSOLE: Thread: \(Thread.isMainThread ? "MAIN" : "BACKGROUND")")
            print("🚨 CONSOLE: Client ID: \(debugClientId)")
            receivedMessages.append("🚨 STATE CHANGE: isConnected = \(isConnected)")
        }
    }
    @Published var connectionStatus = "Disconnected" {
        didSet {
            print("📝 CONSOLE: connectionStatus changed to: \(connectionStatus)")
        }
    }
    @Published var deviceStates = DeviceStates()
    @Published var receivedMessages: [String] = []
    
    private let host: String
    private let port: UInt16
    private var webSocketTask: URLSessionWebSocketTask?
    private var urlSession: URLSession?
    private var connectAttempts = 0
    private var pingTimer: Timer?
    private let clientId = UUID().uuidString // Unique client identifier
    
    // Expose clientId for debugging
    var debugClientId: String { return clientId }
    
    // MQTT Topics matching the Raspberry Pi listener
    private let topics = [
        "home/light",   // GPIO 17 - Living Room Light
        "home/fan",     // GPIO 27 - Ceiling Fan  
        "home/door"     // GPIO 22 - Front Door Servo
    ]
    
    init(host: String, port: UInt16 = 9001) {
        self.host = host
        self.port = port
        super.init()
        print("🏗️ CONSOLE: Created new MQTT client with ID: \(debugClientId)")
        receivedMessages.append("🏗️ Client created with ID: \(debugClientId)")
    }
    
    func connect() {
        disconnect()
        connectAttempts += 1
        
        updateStatus("Connecting to Simpson's House... (Attempt \(connectAttempts))")
        
        guard let wsURL = URL(string: "ws://\(host):\(port)") else {
            updateStatus("Invalid URL")
            return
        }
        
        var request = URLRequest(url: wsURL)
        request.setValue("mqtt", forHTTPHeaderField: "Sec-WebSocket-Protocol")
        request.timeoutInterval = 30.0
        
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 30.0
        config.timeoutIntervalForResource = 60.0
        config.waitsForConnectivity = true
        
        urlSession = URLSession(configuration: config, delegate: self, delegateQueue: nil)
        webSocketTask = urlSession?.webSocketTask(with: request)
        webSocketTask?.resume()
        
        receiveMessage()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 30.0) {
            if !self.isConnected {
                self.updateStatus("Connection timeout")
                if self.connectAttempts < 3 {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
                        self.connect()
                    }
                } else {
                    self.updateStatus("Failed to connect after 3 attempts")
                    self.connectAttempts = 0
                }
            }
        }
    }
    
    func disconnect() {
        pingTimer?.invalidate()
        pingTimer = nil
        webSocketTask?.cancel(with: .goingAway, reason: nil)
        webSocketTask = nil
        urlSession?.invalidateAndCancel()
        urlSession = nil
        
        DispatchQueue.main.async {
            self.isConnected = false
            self.updateStatus("Disconnected from Simpson's House")
        }
    }
    
    // MARK: - Simpson's House Device Controls
    func toggleLight() {
        let newState = !deviceStates.lightOn
        deviceStates.lightOn = newState
        receivedMessages.append("DEBUG: Light toggled to \(newState ? "ON" : "OFF")")
        publishCommand(topic: "home/light", command: newState ? "ON" : "OFF", device: "Living Room Light")
    }
    
    func toggleFan() {
        let newState = !deviceStates.fanOn
        deviceStates.fanOn = newState
        receivedMessages.append("DEBUG: Fan toggled to \(newState ? "ON" : "OFF")")
        publishCommand(topic: "home/fan", command: newState ? "ON" : "OFF", device: "Ceiling Fan")
    }
    
    func toggleDoor() {
        let newState = !deviceStates.doorOpen
        deviceStates.doorOpen = newState
        receivedMessages.append("DEBUG: Door toggled to \(newState ? "OPEN" : "CLOSED")")
        publishCommand(topic: "home/door", command: newState ? "ON" : "OFF", device: "Front Door")
    }
    
    private func publishCommand(topic: String, command: String, device: String) {
        guard isConnected else {
            updateStatus("Not connected - cannot control \(device)")
            return
        }
        
        let publishPacket = createMQTTPublishPacket(topic: topic, message: command)
        let message = URLSessionWebSocketTask.Message.data(publishPacket)
        
        webSocketTask?.send(message) { [weak self] error in
            DispatchQueue.main.async {
                if let error = error {
                    self?.updateStatus("\(device) control failed: \(error.localizedDescription)")
                    if topic == "home/light" { self?.deviceStates.lightOn.toggle() }
                    else if topic == "home/fan" { self?.deviceStates.fanOn.toggle() }
                    else if topic == "home/door" { self?.deviceStates.doorOpen.toggle() }
                } else {
                    self?.receivedMessages.append("📤 \(device): \(command)")
                    self?.updateStatus("✅ \(device) turned \(command)")
                }
            }
        }
    }
    
    // MARK: - MQTT Protocol Implementation
    private func receiveMessage() {
        webSocketTask?.receive { [weak self] result in
            switch result {
            case .success(let message):
                DispatchQueue.main.async {
                    switch message {
                    case .data(let data):
                        self?.handleMQTTData(data)
                    case .string(let text):
                        self?.receivedMessages.append("TEXT: \(text)")
                    @unknown default:
                        break
                    }
                }
                self?.receiveMessage()
                
            case .failure(let error):
                DispatchQueue.main.async {
                    self?.updateStatus("Connection error: \(error.localizedDescription)")
                }
            }
        }
    }
    
    private func sendMQTTConnect() {
        let connectPacket = createMQTTConnectPacket()
        let message = URLSessionWebSocketTask.Message.data(connectPacket)
        
        webSocketTask?.send(message) { [weak self] error in
            DispatchQueue.main.async {
                if let error = error {
                    self?.updateStatus("MQTT handshake failed: \(error.localizedDescription)")
                } else {
                    self?.updateStatus("Connecting to house systems...")
                }
            }
        }
    }
    
    private func handleMQTTData(_ data: Data) {
        guard data.count >= 2 else { return }
        
        let messageType = (data[0] >> 4) & 0x0F
        
        print("🔍 CONSOLE: handleMQTTData called with message type: \(messageType)")
        receivedMessages.append("DEBUG: Received MQTT message type: \(messageType), data length: \(data.count)")
        
        switch messageType {
        case 2: // CONNACK
            print("✅ CONSOLE: Processing CONNACK message")
            receivedMessages.append("DEBUG: Processing CONNACK message")
            if data.count >= 4 {
                let returnCode = data[3]
                print("📊 CONSOLE: CONNACK return code: \(returnCode)")
                receivedMessages.append("DEBUG: CONNACK return code: \(returnCode)")
                
                if returnCode == 0 {
                    print("🎯 CONSOLE: CONNACK SUCCESS - About to set isConnected = true")
                    receivedMessages.append("🚨 FORCING CONNECTION STATE TO TRUE!")
                    
                    print("🧵 CONSOLE: Current thread: \(Thread.isMainThread ? "MAIN" : "BACKGROUND")")
                    print("🔍 CONSOLE: isConnected BEFORE: \(self.isConnected)")
                    
                    // Method 1: Immediate set
                    self.isConnected = true
                    print("🔍 CONSOLE: isConnected AFTER immediate set: \(self.isConnected)")
                    
                    // Method 2: Main queue dispatch
                    DispatchQueue.main.async {
                        print("🚀 CONSOLE: In main queue dispatch")
                        print("🔍 CONSOLE: isConnected in main queue BEFORE: \(self.isConnected)")
                        
                        self.isConnected = true
                        self.updateStatus("🎉 CONNECTED! Simpson's House is now online!")
                        self.receivedMessages.append("✅ MQTT Connected to House Systems")
                        self.startKeepAlive()
                        
                        print("🔍 CONSOLE: isConnected in main queue AFTER: \(self.isConnected)")
                        print("🔄 CONSOLE: Calling objectWillChange.send()")
                        self.objectWillChange.send()
                        
                        // Triple-check with delay
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            print("⏰ CONSOLE: Delayed check - isConnected: \(self.isConnected)")
                            self.isConnected = true
                            self.objectWillChange.send()
                        }
                    }
                    
                    print("📝 CONSOLE: Final check - isConnected: \(self.isConnected)")
                    receivedMessages.append("🚨 isConnected is now: \(self.isConnected)")
                } else {
                    print("❌ CONSOLE: CONNACK failed with code: \(returnCode)")
                    DispatchQueue.main.async {
                        self.updateStatus("Connection failed with code: \(returnCode)")
                    }
                }
            }
        case 3: // PUBLISH (status updates from Pi)
            receivedMessages.append("📨 House status update received")
        case 13: // PINGRESP
            receivedMessages.append("🏓 House connection healthy")
        default:
            receivedMessages.append("DEBUG: Unknown MQTT message type: \(messageType)")
            break
        }
    }
    
    private func startKeepAlive() {
        pingTimer = Timer.scheduledTimer(withTimeInterval: 60.0, repeats: true) { [weak self] _ in
            self?.sendKeepAlive()
        }
    }
    
    private func sendKeepAlive() {
        guard isConnected else { return }
        
        let pingPacket = Data([0xC0, 0x00])
        let message = URLSessionWebSocketTask.Message.data(pingPacket)
        
        webSocketTask?.send(message) { [weak self] error in
            if let error = error {
                print("Keep-alive failed: \(error)")
                DispatchQueue.main.async {
                    self?.updateStatus("Keep-alive failed - checking connection...")
                }
            } else {
                DispatchQueue.main.async {
                    self?.receivedMessages.append("Keep-alive sent")
                }
            }
        }
    }
    
    private func updateStatus(_ status: String) {
        DispatchQueue.main.async {
            self.connectionStatus = status
        }
    }
    
    // MANUAL FIX FUNCTION
    func forceConnectionFix() {
        print("🔧 CONSOLE: MANUAL FIX BUTTON PRESSED!")
        print("🔧 CONSOLE: Current isConnected state: \(self.isConnected)")
        print("🔧 CONSOLE: Thread: \(Thread.isMainThread ? "MAIN" : "BACKGROUND")")
        print("🔧 CONSOLE: Client ID: \(debugClientId)")
        
        receivedMessages.append("🔧 MANUAL FIX BUTTON PRESSED!")
        receivedMessages.append("🔧 Current isConnected state: \(self.isConnected)")
        
        // FORCE the connection state to true immediately
        print("🚀 CONSOLE: About to force isConnected = true")
        receivedMessages.append("🔧 FORCING isConnected = true RIGHT NOW!")
        
        // Method 1: Direct set
        self.isConnected = true
        print("🔍 CONSOLE: After direct set, isConnected = \(self.isConnected)")
        
        // Method 2: Main queue
        DispatchQueue.main.async {
            print("📱 CONSOLE: In force fix main queue")
            print("📱 CONSOLE: isConnected before main queue update: \(self.isConnected)")
            
            self.isConnected = true
            self.updateStatus("🔧 MANUALLY FIXED - House is Connected!")
            self.receivedMessages.append("🔧 Manual fix applied successfully")
            
            print("📱 CONSOLE: isConnected after main queue update: \(self.isConnected)")
            print("📱 CONSOLE: Sending objectWillChange")
            self.objectWillChange.send()
            
            // Multiple follow-up updates
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                print("⏰ CONSOLE: First delayed update")
                self.isConnected = true
                self.updateStatus("🔧 MANUALLY FIXED - House is Connected!")
                self.objectWillChange.send()
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                    print("⏰ CONSOLE: Second delayed update")
                    self.isConnected = true
                    self.objectWillChange.send()
                }
            }
        }
        
        print("🏁 CONSOLE: Force fix completed, final isConnected = \(self.isConnected)")
        receivedMessages.append("🔧 After manual fix, isConnected = \(self.isConnected)")
    }
    
    // MARK: - MQTT Packet Creation
    private func createMQTTConnectPacket() -> Data {
        var packet = Data()
        packet.append(0x10)
        
        let protocolName = "MQTT"
        let protocolNameData = Data(protocolName.utf8)
        
        var variableHeader = Data()
        variableHeader.append(contentsOf: [0x00, UInt8(protocolNameData.count)])
        variableHeader.append(protocolNameData)
        variableHeader.append(0x04)
        variableHeader.append(0x02)
        variableHeader.append(contentsOf: [0x00, 0x3C])
        
        let clientId = "SimpsonsHouse_iOS_\(Int.random(in: 1000...9999))"
        let clientIdData = Data(clientId.utf8)
        
        var payload = Data()
        payload.append(contentsOf: [0x00, UInt8(clientIdData.count)])
        payload.append(clientIdData)
        
        let remainingLength = variableHeader.count + payload.count
        packet.append(UInt8(remainingLength))
        packet.append(variableHeader)
        packet.append(payload)
        
        return packet
    }
    
    private func createMQTTPublishPacket(topic: String, message: String) -> Data {
        var packet = Data()
        packet.append(0x30)
        
        let topicData = Data(topic.utf8)
        var variableHeader = Data()
        variableHeader.append(contentsOf: [0x00, UInt8(topicData.count)])
        variableHeader.append(topicData)
        
        let messageData = Data(message.utf8)
        let remainingLength = variableHeader.count + messageData.count
        packet.append(UInt8(remainingLength))
        packet.append(variableHeader)
        packet.append(messageData)
        
        return packet
    }
}

// MARK: - URLSession Delegate
extension SimpsonsHouseMQTTClient: URLSessionWebSocketDelegate {
    func urlSession(_ session: URLSession, webSocketTask: URLSessionWebSocketTask, didOpenWithProtocol protocol: String?) {
        DispatchQueue.main.async {
            self.updateStatus("WebSocket connected - Initializing house systems...")
            self.receivedMessages.append("🔌 WebSocket connection established")
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.receivedMessages.append("📡 Sending MQTT connect packet...")
            self.sendMQTTConnect()
        }
    }
    
    func urlSession(_ session: URLSession, webSocketTask: URLSessionWebSocketTask, didCloseWith closeCode: URLSessionWebSocketTask.CloseCode, reason: Data?) {
        DispatchQueue.main.async {
            self.pingTimer?.invalidate()
            self.isConnected = false
            
            let reasonString = reason != nil ? String(data: reason!, encoding: .utf8) ?? "Unknown" : "Network connection lost"
            self.updateStatus("Connection lost: \(reasonString)")
            self.receivedMessages.append("WebSocket closed: \(closeCode.rawValue)")
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
                if !self.isConnected && self.connectAttempts < 5 {
                    self.updateStatus("Auto-reconnecting to Simpson's House...")
                    self.connect()
                }
            }
        }
    }
    
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error = error {
            DispatchQueue.main.async {
                self.isConnected = false
                self.updateStatus("Connection error: \(error.localizedDescription)")
                self.receivedMessages.append("Error: \(error.localizedDescription)")
                print("Detailed error: \(error)")
                
                let nsError = error as NSError
                if nsError.code != -1005 {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                        if !self.isConnected && self.connectAttempts < 3 {
                            self.updateStatus("Retrying connection...")
                            self.connect()
                        }
                    }
                }
            }
        }
    }
}

// MARK: - Device States Model
class DeviceStates: ObservableObject {
    @Published var lightOn = false
    @Published var fanOn = false
    @Published var doorOpen = false
}

// MARK: - Main App View
struct ContentView: View {
    @StateObject private var mqttClient = SimpsonsHouseMQTTClient(host: "192.168.5.115")
    @State private var showingLogs = false
    @State private var showingInfo = false
    @State private var forceRefresh = false // Force UI refresh trigger
    
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(spacing: 24) {
                    // Hero Section
                    HeroSectionView()
                        .padding(.top, 8)
                    
                    // Connection Status Card - force observation
                    ConnectionStatusCard(
                        mqttClient: mqttClient,
                        showingInfo: $showingInfo,
                        showingLogs: $showingLogs
                    )
                    .id("connection-\(mqttClient.isConnected)-\(forceRefresh)") // Force recreation
                    
                    // Debug Connection Info
                    DebugConnectionView(mqttClient: mqttClient)
                        .id("debug-\(mqttClient.isConnected)-\(forceRefresh)") // Force recreation
                    
                    // Device Controls Section with forced UI updates
                    Group {
                        let shouldShowControls = mqttClient.isConnected
                        let _ = print("🎯 CONSOLE: ContentView evaluation - isConnected: \(mqttClient.isConnected), shouldShowControls: \(shouldShowControls)")
                        
                        if shouldShowControls {
                            let _ = print("✅ CONSOLE: Showing DeviceControlsSection")
                            DeviceControlsSection(mqttClient: mqttClient)
                                .id("controls-\(mqttClient.isConnected)-\(forceRefresh)") // Force recreation
                        } else {
                            let _ = print("❌ CONSOLE: Showing ConnectionPromptView")
                            ConnectionPromptView()
                                .id("prompt-\(mqttClient.isConnected)-\(forceRefresh)") // Force recreation
                        }
                    }
                    
                    Spacer(minLength: 100)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 40)
            }
            .background(
                LinearGradient(
                    colors: [Color.blue.opacity(0.03), Color.green.opacity(0.03), Color.purple.opacity(0.02)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
            )
            .navigationBarHidden(true)
            .onAppear {
                print("🏠 CONSOLE: ContentView appeared with client ID: \(mqttClient.debugClientId)")
            }
            .onReceive(mqttClient.objectWillChange) { _ in
                // Force UI refresh when mqtt client changes
                print("🔄 CONSOLE: MQTT Client changed - forcing UI refresh")
                forceRefresh.toggle()
            }
        }
        .sheet(isPresented: $showingLogs) {
            LogsView(messages: mqttClient.receivedMessages)
        }
        .sheet(isPresented: $showingInfo) {
            InfoView()
        }
    }
}

// MARK: - Hero Section
struct HeroSectionView: View {
    var body: some View {
        VStack(spacing: 16) {
            ZStack {
                Circle()
                    .strokeBorder(
                        LinearGradient(
                            colors: [.white.opacity(0.8), .blue.opacity(0.3), .white.opacity(0.6)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 3
                    )
                    .frame(width: 100, height: 100)
                
                Circle()
                    .frame(width: 80, height: 80)
                    .background(.ultraThinMaterial, in: Circle())
                
                Image(systemName: "house.fill")
                    .font(.system(size: 36, weight: .medium, design: .rounded))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.blue, .purple, .indigo],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
            }
            
            VStack(spacing: 6) {
                Text("Simpson's House")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .fontDesign(.rounded)
                
                Text("Smart Home Control")
                    .font(.title3)
                    .fontWeight(.medium)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 20)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 24))
        .overlay(
            RoundedRectangle(cornerRadius: 24)
                .strokeBorder(.white.opacity(0.3), lineWidth: 1)
        )
    }
}

// MARK: - Debug Connection View
struct DebugConnectionView: View {
    let mqttClient: SimpsonsHouseMQTTClient
    
    var body: some View {
        VStack(spacing: 12) {
            Text("🐛 Debug Info")
                .font(.headline)
                .fontWeight(.bold)
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Client ID: \(mqttClient.debugClientId.prefix(8))...")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                
                Text("Connection State: \(mqttClient.isConnected ? "✅ CONNECTED" : "❌ DISCONNECTED")")
                    .font(.caption)
                    .foregroundStyle(mqttClient.isConnected ? .green : .red)
                
                Text("Status: \(mqttClient.connectionStatus)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                
                // Show evidence of connection
                if mqttClient.receivedMessages.contains(where: { $0.contains("CONNACK return code: 0") }) {
                    Text("🎯 MQTT SUCCESS DETECTED IN LOGS!")
                        .font(.caption)
                        .fontWeight(.bold)
                        .foregroundStyle(.orange)
                }
                
                // NEW: Show if device controls should be visible
                Text("Device Controls Should Show: \(mqttClient.isConnected ? "YES" : "NO")")
                    .font(.caption)
                    .fontWeight(.bold)
                    .foregroundStyle(mqttClient.isConnected ? .green : .red)
                
                // NEW: Current timestamp for debugging
                Text("Last Update: \(Date().formatted(.dateTime.hour().minute().second()))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            
            // MANUAL FIX BUTTON
            Button("🔧 FORCE FIX CONNECTION") {
                print("🔧 CONSOLE: Manual fix button tapped!")
                mqttClient.forceConnectionFix()
            }
            .font(.headline)
            .fontWeight(.bold)
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 44)
            .background(.orange.gradient, in: RoundedRectangle(cornerRadius: 12))
        }
        .padding(16)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .strokeBorder(.orange.opacity(0.5), lineWidth: 2)
        )
        .onAppear {
            print("🐛 CONSOLE: DebugConnectionView appeared for client: \(mqttClient.debugClientId)")
        }
    }
}

// MARK: - Connection Status Card
struct ConnectionStatusCard: View {
    @ObservedObject var mqttClient: SimpsonsHouseMQTTClient
    @Binding var showingInfo: Bool
    @Binding var showingLogs: Bool
    
    var body: some View {
        VStack(spacing: 18) {
            HStack {
                HStack(spacing: 10) {
                    Circle()
                        .fill(mqttClient.isConnected ? .green : .red)
                        .frame(width: 10, height: 10)
                    
                    Text(mqttClient.isConnected ? "Connected" : "Disconnected")
                        .font(.caption)
                        .fontWeight(.semibold)
                        .foregroundStyle(mqttClient.isConnected ? .green : .red)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(.thinMaterial, in: Capsule())
                
                Spacer()
                
                HStack(spacing: 16) {
                    Button {
                        showingInfo = true
                    } label: {
                        Image(systemName: "info.circle.fill")
                            .font(.title3)
                            .foregroundStyle(.blue)
                            .frame(width: 36, height: 36)
                            .background(.thinMaterial, in: Circle())
                    }
                    
                    Button {
                        showingLogs = true
                    } label: {
                        Image(systemName: "list.bullet.circle.fill")
                            .font(.title3)
                            .foregroundStyle(.purple)
                            .frame(width: 36, height: 36)
                            .background(.thinMaterial, in: Circle())
                    }
                }
            }
            
            Text(mqttClient.connectionStatus)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
            
            HStack(spacing: 16) {
                Button {
                    print("🔘 CONSOLE: Connection button tapped - current state: \(mqttClient.isConnected)")
                    if mqttClient.isConnected {
                        mqttClient.disconnect()
                    } else {
                        mqttClient.connect()
                    }
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: mqttClient.isConnected ? "house.slash.fill" : "house.fill")
                            .font(.title3)
                        
                        Text(mqttClient.isConnected ? "Disconnect" : "Connect")
                            .font(.headline)
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 54)
                    .foregroundStyle(.white)
                    .background(
                        LinearGradient(
                            colors: mqttClient.isConnected ? [.red, .orange] : [.blue, .indigo],
                            startPoint: .leading,
                            endPoint: .trailing
                        ),
                        in: RoundedRectangle(cornerRadius: 16)
                    )
                }
            }
        }
        .padding(24)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 20))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .strokeBorder(.white.opacity(0.3), lineWidth: 1)
        )
        .onChange(of: mqttClient.isConnected) { oldValue, newValue in
            print("🔄 CONSOLE: ConnectionStatusCard detected isConnected change: \(oldValue) → \(newValue)")
        }
    }
}

// MARK: - Device Controls Section
struct DeviceControlsSection: View {
    @ObservedObject var mqttClient: SimpsonsHouseMQTTClient
    
    var body: some View {
        VStack(spacing: 20) {
            HStack {
                Text("🎉 House is Online!")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundStyle(.green)
                
                Spacer()
                
                // Show active devices count
                Text("\(activeDevicesCount)/3 Active")
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundStyle(.white)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(.green.gradient, in: Capsule())
            }
            
            LazyVGrid(columns: [
                GridItem(.flexible(), spacing: 16),
                GridItem(.flexible(), spacing: 16)
            ], spacing: 16) {
                DeviceCard(
                    icon: "lightbulb.fill",
                    title: "Living Room",
                    subtitle: "Light",
                    isOn: mqttClient.deviceStates.lightOn,
                    accentColor: .yellow,
                    action: {
                        print("💡 CONSOLE: Light toggle action - current: \(mqttClient.deviceStates.lightOn)")
                        mqttClient.toggleLight()
                    }
                )
                
                DeviceCard(
                    icon: "fan.fill",
                    title: "Ceiling",
                    subtitle: "Fan",
                    isOn: mqttClient.deviceStates.fanOn,
                    accentColor: .cyan,
                    action: {
                        print("🌀 CONSOLE: Fan toggle action - current: \(mqttClient.deviceStates.fanOn)")
                        mqttClient.toggleFan()
                    }
                )
                
                DeviceCard(
                    icon: "door.right.hand.open",
                    title: "Front Door",
                    subtitle: "Security",
                    isOn: mqttClient.deviceStates.doorOpen,
                    accentColor: .brown,
                    action: {
                        print("🚪 CONSOLE: Door toggle action - current: \(mqttClient.deviceStates.doorOpen)")
                        mqttClient.toggleDoor()
                    }
                )
                .gridCellColumns(2)
            }
        }
        .padding(24)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 20))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .strokeBorder(.green.opacity(0.3), lineWidth: 2)
        )
        .onChange(of: mqttClient.deviceStates.lightOn) { oldValue, newValue in
            print("💡 CONSOLE: DeviceControlsSection detected light change: \(oldValue) → \(newValue)")
        }
        .onChange(of: mqttClient.deviceStates.fanOn) { oldValue, newValue in
            print("🌀 CONSOLE: DeviceControlsSection detected fan change: \(oldValue) → \(newValue)")
        }
        .onChange(of: mqttClient.deviceStates.doorOpen) { oldValue, newValue in
            print("🚪 CONSOLE: DeviceControlsSection detected door change: \(oldValue) → \(newValue)")
        }
    }
    
    private var activeDevicesCount: Int {
        var count = 0
        if mqttClient.deviceStates.lightOn { count += 1 }
        if mqttClient.deviceStates.fanOn { count += 1 }
        if mqttClient.deviceStates.doorOpen { count += 1 }
        return count
    }
}

// MARK: - Device Card
struct DeviceCard: View {
    let icon: String
    let title: String
    let subtitle: String
    let isOn: Bool
    let accentColor: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: {
            print("🎛️ CONSOLE: Device button tapped - \(title) - current state: \(isOn)")
            action()
        }) {
            VStack(spacing: 12) {
                HStack {
                    ZStack {
                        Circle()
                            .fill(isOn ? accentColor.opacity(0.2) : Color(.systemGray6))
                            .frame(width: 48, height: 48)
                        
                        Image(systemName: icon)
                            .font(.title2)
                            .fontWeight(.medium)
                            .foregroundStyle(isOn ? accentColor : .secondary)
                    }
                    
                    Spacer()
                    
                    ZStack {
                        Circle()
                            .fill(isOn ? accentColor : Color(.systemGray4))
                            .frame(width: 20, height: 20)
                        
                        if isOn {
                            Circle()
                                .fill(.white)
                                .frame(width: 8, height: 8)
                        }
                    }
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundStyle(.primary)
                    
                    Text(subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    
                    // Add current state indicator
                    Text(isOn ? "ON" : "OFF")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundStyle(isOn ? accentColor : .secondary)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 2)
                        .background(
                            Capsule()
                                .fill(isOn ? accentColor.opacity(0.1) : Color(.systemGray6))
                        )
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(16)
            .frame(maxWidth: .infinity)
            .frame(height: 120)
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .strokeBorder(isOn ? accentColor.opacity(0.5) : .clear, lineWidth: 2)
            )
        }
        .buttonStyle(PlainButtonStyle())
        .id("device-\(title)-\(isOn)") // Force recreation when state changes
    }
}

// MARK: - Connection Prompt
struct ConnectionPromptView: View {
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "wifi.slash")
                .font(.system(size: 56))
                .foregroundStyle(.secondary)
            
            VStack(spacing: 12) {
                Text("Connect to Get Started")
                    .font(.title3)
                    .fontWeight(.semibold)
                
                Text("Connect to Simpson's House to control your smart home devices")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
        .padding(32)
        .frame(maxWidth: .infinity)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 20))
    }
}

// MARK: - Info View
struct InfoView: View {
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Simpson's House Control")
                            .font(.title2)
                            .fontWeight(.bold)
                        
                        Text("Smart home automation system using MQTT over WebSocket")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 8)
                }
                
                Section("Hardware Configuration") {
                    InfoRow(icon: "lightbulb.fill", iconColor: .yellow, title: "Living Room Light", detail: "GPIO Pin 17")
                    InfoRow(icon: "fan.fill", iconColor: .cyan, title: "Ceiling Fan", detail: "GPIO Pin 27")
                    InfoRow(icon: "door.right.hand.open", iconColor: .brown, title: "Front Door Servo", detail: "GPIO Pin 22")
                }
                
                Section("Network Configuration") {
                    InfoRow(icon: "server.rack", iconColor: .green, title: "Raspberry Pi", detail: "192.168.5.115")
                    InfoRow(icon: "network", iconColor: .purple, title: "WebSocket Port", detail: "9001")
                    InfoRow(icon: "antenna.radiowaves.left.and.right", iconColor: .orange, title: "MQTT Topics", detail: "home/light, home/fan, home/door")
                }
            }
            .navigationTitle("System Information")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
    }
}

// MARK: - Info Row
struct InfoRow: View {
    let icon: String
    let iconColor: Color
    let title: String
    let detail: String
    
    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundStyle(iconColor)
                .frame(width: 28, height: 28)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.subheadline)
                    .fontWeight(.medium)
                
                Text(detail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            
            Spacer()
        }
        .padding(.vertical, 6)
    }
}

// MARK: - Logs View
struct LogsView: View {
    let messages: [String]
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationStack {
            Group {
                if messages.isEmpty {
                    ContentUnavailableView(
                        "No Activity Yet",
                        systemImage: "list.bullet.clipboard",
                        description: Text("Connect to Simpson's House to see activity logs")
                    )
                } else {
                    List {
                        Section("Recent Activity") {
                            ForEach(Array(messages.suffix(100).reversed().enumerated()), id: \.offset) { index, message in
                                HStack(spacing: 12) {
                                    Text(getMessageIcon(for: message))
                                        .font(.caption)
                                    
                                    Text(message)
                                        .font(.system(.footnote, design: .monospaced))
                                        .foregroundStyle(.primary)
                                }
                                .padding(.vertical, 4)
                            }
                        }
                    }
                }
            }
            .navigationTitle("Activity Logs")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
    }
    
    private func getMessageIcon(for message: String) -> String {
        if message.contains("Connected") { return "✅" }
        if message.contains("failed") || message.contains("Error") { return "❌" }
        if message.contains("Keep-alive") { return "🏓" }
        if message.contains("DEBUG") { return "🐛" }
        if message.contains("FORCING") { return "🚨" }
        if message.contains("ON") || message.contains("OFF") { return "🏠" }
        return "📨"
    }
}

#Preview {
    ContentView()
}
