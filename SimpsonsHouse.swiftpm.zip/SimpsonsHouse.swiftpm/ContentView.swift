import SwiftUI
import SwiftMQTT

/// SwiftUI view for controlling MQTT topics directly from a Playground App
struct ContentView: View {
    // MARK: - MQTT Client
    private let mqtt = MQTTSession(
        host: "tkcraspberry.local", // or your Pi’s IP address
        port: 1883,
        clientID: "playground-\(UUID())",
        cleanSession: true,
        keepAlive: 60,
        useSSL: false
    )
    
    // MARK: - UI State
    @State private var lightsOn = false
    @State private var fanOn    = false
    @State private var doorOpen = false
    
    var body: some View {
        VStack(spacing: 24) {
            Text("Simpson’s House")
                .font(.title2)
                .bold()
            
            Toggle("Lights", isOn: $lightsOn)
                .onChange(of: lightsOn) { _, isOn in
                    publish(to: "home/light", value: isOn)
                }
            
            Toggle("Fan", isOn: $fanOn)
                .onChange(of: fanOn) { _, isOn in
                    publish(to: "home/fan", value: isOn)
                }
            
            Toggle("Door", isOn: $doorOpen)
                .onChange(of: doorOpen) { _, isOn in
                    publish(to: "home/door", value: isOn)
                }
        }
        .padding()
        .onAppear {
            connectMQTT()
        }
    }
    
    // MARK: - MQTT Helpers
    
    private func connectMQTT() {
        mqtt.connect { error in
            if error == .none {
                print("✅ MQTT connected")
            } else {
                print("❌ MQTT connect error:", error)
            }
        }
    }
    
    private func publish(to topic: String, value: Bool) {
        let payload = (value ? "ON" : "OFF").data(using: .utf8)!
        mqtt.publish(
            payload,
            in: topic,
            delivering: .atLeastOnce,
            retain: false
        ) { error in
            if error == .none {
                print("✅ Published to \(topic): \(value ? "ON" : "OFF")")
            } else {
                print("❌ Publish error on \(topic):", error)
            }
        }
    }
}
