import SwiftUI

// =============================================================================
// InfoView.swift — Hardware Information Sheet
// =============================================================================
// A reference sheet showing the GPIO pin assignments and network settings
// for the Raspberry Pi. Opens when the user taps the info (ⓘ) button.
//
// You can customise the layout and styling here if you like.
// The data in each InfoRow reflects the actual hardware wiring.
// =============================================================================

struct InfoView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Simpson's House Control")
                            .font(.title2)
                            .fontWeight(.bold)

                        Text("Smart home automation system using MQTT over WebSocket")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 8)
                }

                Section("Hardware Configuration") {
                    InfoRow(icon: "lightbulb.fill",          iconColor: .yellow, title: "Living Room Light",  detail: "GPIO Pin 17")
                    InfoRow(icon: "garage",                  iconColor: .orange, title: "Garage Door Opener", detail: "Servo Motor - GPIO Pin 27")
                    InfoRow(icon: "door.right.hand.open",    iconColor: .brown,  title: "Front Door Servo",   detail: "GPIO Pin 23")
                }

                Section("Network Configuration") {
                    InfoRow(icon: "server.rack",                          iconColor: .green,  title: "Raspberry Pi",    detail: "192.168.5.123")
                    InfoRow(icon: "network",                              iconColor: .purple, title: "WebSocket Port",  detail: "9001")
                    InfoRow(icon: "antenna.radiowaves.left.and.right",   iconColor: .orange, title: "MQTT Topics",     detail: "home/light, home/garage, home/door")
                }

                Section("Garage Door Control") {
                    InfoRow(icon: "garage.open",      iconColor: .orange, title: "Door Operation", detail: "OPEN/CLOSE commands")
                    InfoRow(icon: "gear",             iconColor: .orange, title: "Motor Type",     detail: "SG90 Servo Motor")
                    InfoRow(icon: "angle",            iconColor: .orange, title: "Travel Range",   detail: "0° (closed) → 90° (open)")
                }
            }
            .navigationTitle("System Information")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
    }
}

// MARK: - Info Row Helper

struct InfoRow: View {
    let icon: String
    let iconColor: Color
    let title: String
    let detail: String

    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundStyle(iconColor)
                .frame(width: 28, height: 28)

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.subheadline)
                    .fontWeight(.medium)

                Text(detail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()
        }
        .padding(.vertical, 6)
    }
}
